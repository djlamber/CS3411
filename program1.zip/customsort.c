#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

int main(int argc,char** argv[]) {
  int buffsize = 100;
  char buff[buffsize];
  char* file;
  int fileP = 0;
  ssize_t num;
  char str[10];
  int inputfile;
  int outputfile;
  int filesize;
  int i;
  int j;
  int numlines = 0;
  int linelen = 0;
  int maxlinelen = 0;
  int lineP=0;

  /* the number of arguments is invalid*/
  if(argc != 2 && argc != 3){
    sprintf(str,"Incorrect number of arguments, please follow the format provided:");
    puts(str);
    sprintf(str,"customsort file_to_be_sorted output_file(optional)");
    puts(str);
    return 1;
  }

  /*open and read input file*/
  inputfile = open(argv[1], O_RDONLY); 
  if(inputfile == -1){
    sprintf(str,"Error opening input file");
    puts(str);
    return 1;
  }
  filesize = lseek(inputfile, 0, SEEK_END);
  lseek(inputfile, 0, SEEK_SET);
  file = (char *) malloc(filesize);
 
  num = 1;
  while(num > 0){
    memset(buff, 0, buffsize);
    num = read(inputfile, buff, buffsize);
    if(num == -1){
      sprintf(str,"Error reading input file");
      puts(str);
      close(inputfile);
      return 1;
    }
    /*copies from buffer to file string and figures out number of lines and the longest line*/
    i = 0;
    for(i; i<num; i++){
      file[fileP] = buff[i];
      if(file[fileP] == '\n'){
	numlines++;
	if(linelen > maxlinelen){
	  maxlinelen = linelen+1;
	}
	linelen = -1;
      }
      linelen++;
      fileP++;
    }
  }
  close(inputfile);
  /*split up file line by line*/
  char lines[numlines][maxlinelen];
  fileP=0;
  lineP=0;
  i=0;
  for(fileP; fileP<filesize; fileP++){
    if(file[fileP] == '\n'){
      lines[lineP][i]='\n';
      lineP++;
      i=0;
    }else{
      lines[lineP][i]=file[fileP];
      i++;
    }
  }
  free(file);
  /*sort each line*/
  char temp[maxlinelen][maxlinelen];
  int tempx;
  int tempy;
  int numwords;
  int finallineP;
  char finallines[numlines][maxlinelen];
  memset(finallines, 0, numlines*maxlinelen);
  /*goes through each line one by one*/
  for(lineP=0; lineP<numlines; lineP++){
    i=0;
    tempx=0;
    tempy=0;
    numwords=0;
    finallineP=0;
    memset(temp,0,maxlinelen*maxlinelen);
    /*copies line into temp word by word and counds number of words*/
    for(i; i<maxlinelen; i++){
      if(lines[lineP][i] == ' ' || lines[lineP][i] == '\0'){
	temp[tempx][tempy] = '\0';
	tempx++;
	tempy=0;
	numwords++;
      }else if(lines[lineP][i] == '\n'){
	temp[tempx][tempy] = '\0';
	numwords++;
	break;
      }else{
	temp[tempx][tempy] = lines[lineP][i];
	tempy++;
      }
    }
    /*goes through each line in temp and finds the smallest ASCII value word and copies to to sortedline and then appends it to finalline, this loop for every word*/
    char sortedline[maxlinelen];
    int k;
    int sortedindex = 0;
    for(numwords; numwords>0; numwords--){
      i=0;
      j=0;
      memset(sortedline, 0, maxlinelen);
      for(i=0; i<maxlinelen; i++){
	j=0;
	if(sortedline[j] == '\0'){ /*if sortedline isn't initalized*/
	  for(k=0; k<maxlinelen; k++){
	    sortedline[k] = temp[i][k];
	    sortedindex = i;
	  }
	}else if(temp[i][j] < sortedline[j] && temp[i][j] != '\0' && sortedline[j] != '\0'){ /*if the next word is less than sortedline*/
	  for(k=0; k<maxlinelen; k++){
	    sortedline[k] = temp[i][k];
	    sortedindex = i;
	  }
	}else if(temp[i][j] == sortedline[j] && sortedline[j] == '\0' && temp[i][j] != '\0'){ /*if the next word is equal to sortedline and sortedline isn't inialized*/
	  continue;
	}else if(temp[i][j] == sortedline[j]){ /*if the next word is equal to sortedline*/
	  while(temp[i][j] == sortedline[j]){
	    j++;
	    if(temp[i][j] < sortedline[j]){
	      for(k=0; k<maxlinelen; k++){
		sortedline[k] = temp[i][k];
		sortedindex = i;
	      }
	    }
	  }
	} 
      }
      /*copies next smallest ASCII word to finalline*/
      /*copies sortedline to finallines*/
      for(i=0; i<maxlinelen; i++){
	if(sortedline[i] != '\0' && sortedline[i] != '\n'){
	  finallines[lineP][finallineP] = sortedline[i];
	  finallineP++;
	}
	else{
	  finallines[lineP][finallineP] = ' ';
	  finallineP++;
	  break;
	}
      }
      /*remove the word from temp via sorted index*/
      memset(temp[sortedindex], 0, maxlinelen);
    }
    /*adds new line character at end of finalline before going to next line*/
    finallines[lineP][finallineP-1] = '\n';
  }
  /*deletes duplicates in finallines*/
  int removedlines = numlines;
  for(lineP=0;lineP<numlines-1; lineP++){
    for(i=lineP+1;i<numlines; i++){
      if(strcmp(finallines[lineP],finallines[i])==0){
        memset(finallines[i], 0, maxlinelen);
        removedlines--;
      }
    }
  }
  /*all sorted lines are in finallines, reorganize on sortedfile via sortedline*/
  char sortedline[maxlinelen];
  char sortedfile[filesize];
  int k = 0;
  int sortedindex = 0;
  memset(sortedfile, 0, filesize);
  fileP=0;
  for(lineP=0; lineP<numlines; lineP++){
    memset(sortedline, 0, maxlinelen);
    for(i=0; i<maxlinelen; i++){
      j=0;
      if(sortedline[j] == '\0'){ /*if sortedline isn't initalized*/
	for(k=0; k<maxlinelen; k++){
	  sortedline[k] = finallines[i][k];
	  sortedindex = i;
	}
      }else if(finallines[i][j] < sortedline[j] && finallines[i][j] != '\0' && sortedline[j] != '\0'){ /*if the next word is less than sortedline*/
	for(k=0; k<maxlinelen; k++){
	  sortedline[k] = finallines[i][k];
	  sortedindex = i;
	}
      }else if(finallines[i][j] == sortedline[j] && sortedline[j] == '\0' && finallines[i][j] != '\0'){ /*if the next word is equal to sortedline and sortedline isn't inialized*/
	continue;
      }else if(finallines[i][j] == sortedline[j]){ /*if the next word is equal to sortedline*/
	while(finallines[i][j] == sortedline[j]){
	  j++;
	  if(finallines[i][j] < sortedline[j]){
	    for(k=0; k<maxlinelen; k++){
	      sortedline[k] = finallines[i][k];
	      sortedindex = i;
	    }
	  }
	}
      }
    }
      /*copy sortedline to sortedfile*/
    for(i=0; i<maxlinelen; i++){
      sortedfile[fileP] = sortedline[i];
      fileP++;
      if(sortedline[i] == '\n'){
	sortedfile[fileP] = '\n';
	break;
      }
    }
    /*remove line from finallines*/
    memset(finallines[sortedindex], 0, maxlinelen);
  }
  for(i=fileP;i<filesize;i++){
    sortedfile[i] = '\0';
  }

  /*prints to terminal*/
  if(argc == 2){
    sprintf(str,"%s",sortedfile);
    puts(str);
    return 0;
  }

  /*writes to file*/
  if(argc == 3){
    outputfile = open(argv[2], O_WRONLY);
    /*error opening file*/
    if(outputfile == -1){
      sprintf(str, "Error opening output file\n");
      puts(str);
      close(outputfile);
      return 1;
    }
    /*write to file*/
    for(i=0;i<filesize;i=i+buffsize){
      memset(buff,0,buffsize);
      for(j=0;j<buffsize;j++){
	
	buff[j] = sortedfile[i+j];
      }
      num = write(outputfile,buff,buffsize);
      /*error writing*/
      if(num == -1){
	close(outputfile);
	sprintf(str,"Error writing to output file\n");
	puts(str);
	return 1;
      }
      /*if the write return is less than buff size then stop writing*/
      if(num < buffsize){
	break;
      }
    }
    close(outputfile);
    return 0;
  }
  return 1;
}
