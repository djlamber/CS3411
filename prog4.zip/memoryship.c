#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>

void printboard(char* dst){
  int i = 0;
  char buff[5];
  for(i = 0; i < 50; i++){
    if(i%5 == 0){
      sprintf(buff, "\n");
      write(STDOUT_FILENO, buff, 1);
    }
    if(i == 25){
      int j = 0;
      while(j < 5){
	sprintf(buff, "=");
	write(STDOUT_FILENO, buff, 1);
	sprintf(buff, " ");
	write(STDOUT_FILENO, buff, 1);
	j++;
      }
      sprintf(buff, "\n");
      write(STDOUT_FILENO, buff, 1);
    }
    sprintf(buff, "%c", *dst);
    write(STDOUT_FILENO, buff, 1);
    sprintf(buff, " ");
    write(STDOUT_FILENO, buff, 1);
    dst++;
  }
  sprintf(buff, "\n");
  write(STDOUT_FILENO, buff, 1);
}

int main(int argc, char* argv[]){
  char buff[200];
  if(argc != 2 || atoi(argv[1]) < 1){
    sprintf(buff,"Invalid input please use the following format where turn_speed >= 1:\n./memoryship <turn_speed>");
    puts(buff);
    exit(0);
  }
  int turn_speed = atoi(argv[1]);
  int i = 0;
  int random;
  int hit = 0;
  char *dst;
  int fd = open("/dev/zero", O_RDWR);
  dst = mmap(0, sizeof(char) * 52, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

  srand(time(NULL));
  *dst = '0'; /*game in progress/winner flag*/
  dst++;
  *dst = '1'; /*turn flag*/
  dst++;
  /*initalize board to .*/
  for(i = 0; i < 50; i++){
    *dst = '.';
    dst++;
  }
  dst = dst - 50;
  i = 0;
  
  if(fork() == 0){
    /*player 1*/
    /*initalize ships*/
    dst = dst + 25;
    while(i < 5){
      random = rand()%25;
      dst = dst + random;
      if(*dst == 'O'){
	dst = dst - random;
	continue;
      }else{
	*dst = 'O';
	i++;
	dst = dst - random;
      }
    }
    dst = dst - 26;
    *dst = '2';

    /*game is running*/
    while(1){
      while(*dst != '1');
      usleep(turn_speed);      
      if(*(dst-1) != '0'){
	*dst = '2';
	break;
      }
      /*randomly pick a unhit spot*/
      dst++;
      int k = 1;
      while(k){
	random = rand()%25;
	dst = dst + random;
	if(*dst == '.' || *dst == 'O'){
	  k = 0;
	}else{
	  dst = dst - random;
	}
      }
      /*miss*/
      if(*dst == '.'){
	*dst = '*';
      }
      /*hit*/
      if(*dst == 'O'){
	*dst = 'X';
	hit++;
      }
      dst = dst - random;
      if(hit == 5){
	*(dst-2) = '1';
      }
      printboard(dst);
      dst--;
      *dst = '2';
    }

  }else{
    /*player 2*/
    srand(rand());
    while(*(dst-1) != '2');
    /*initalize ships*/
    while(i < 5){
      random = rand()%25;
      dst = dst + random;
      if(*dst == 'O'){
	dst = dst - random;
	continue;
      }else{
	*dst = 'O';
	i++;
	dst = dst - random;
      }
    }
    printboard(dst);
    dst--;
    *dst = '1';
    /*game is running*/
    while(1){
      while(*dst != '2');
      usleep(turn_speed);
      if(*(dst-1) != '0'){
        *dst = '1';
	exit(0);
      }
      dst = dst + 26;
      /*randomly pick a unhit spot*/
      int k = 1;
      while(k){
        random = rand()%25;
        dst = dst + random;
        if(*dst == '.' || *dst == 'O'){
          k = 0;
        }else{
	  dst = dst - random;
	}
      }
      /*miss*/
      if(*dst == '.'){
        *dst = '*';
      }
      /*hit*/
      if(*dst == 'O'){
        *dst = 'X';
        hit ++;
      }
      dst = dst - random - 26;
      if(hit == 5){
        *(dst-1)  = '2';
      }
      printboard(dst+1);
      *dst = '1';
    }
  }

  /*game finished, print winner*/
  dst--;
  if(*dst == '1'){
    sprintf(buff, "\n\n\nPlayer 1 wins!");
    puts(buff);
  }else if(*dst == '2'){
    sprintf(buff, "\n\n\nPlayer 2 wins!");
    puts(buff);
  }else{
    sprintf(buff, "\n\n\nsomething is wrong :(\n");
    puts(buff);
  }
  exit(0);
}
