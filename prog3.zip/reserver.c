#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <strings.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
int main() {
  int listener, conn, length; char ch;
  int left;
  int put = 0;
  int num;
  int i = 0;
  int commas = 0;
  int recievedlength = 0;
  char msg[] = {"recieved"};
  char recievedmsg[100];
  char buff[100];
  struct sockaddr_in s1, s2;
  listener = socket( AF_INET, SOCK_STREAM, 0 );
  bzero((char *) &s1, sizeof(s1));
  s1.sin_family = (short) AF_INET;
  s1.sin_addr.s_addr = htonl(INADDR_ANY);
  s1.sin_port = htons(0);
  bind(listener, (struct sockaddr *)&s1, sizeof(s1));
  length = sizeof(s1);
  getsockname(listener, (struct sockaddr *)&s1, &length);
  sprintf(buff,"RSTREAM:: assigned port number %d",ntohs(s1.sin_port));
  puts(buff);
  listen(listener,1);
  length = sizeof(s2);
  /*loops until SIGINT is sent*/
  while (1==1) {
    conn=accept(listener, (struct sockaddr *)&s2, &length);
    bzero((char *) &recievedmsg, sizeof(recievedmsg));
    i = 0;
    recievedlength = 0;
    commas = 0;
    while (read(conn, &ch, 1) == 1){
      recievedmsg[i] = ch;
      recievedlength++;
      i++;
      if(ch == ','){
	commas++;
      }
      if(ch == '\0'){
	commas++;
	break;
      }
    }
    /*compares recieved message, if is SIGINT exit*/
    if(strcmp(recievedmsg, "SIGINT") == 0){
      exit(0);
    }
    /*fork for command execution*/
    if(fork() == 0){
      char *cmd;
      char *argv[commas+1];
      int argi = 0;
      char *token;
      token = strtok(recievedmsg, ",");
      cmd = token;
      while(token != NULL){
	argv[argi] = token;
	token = strtok(NULL, ",");
	argi++;
      }
      /*send output from stdout to conn*/
      dup2(conn, STDOUT_FILENO);
      argv[argi] = NULL;
      /*execvp the command*/
      execvp(cmd, argv);
      exit(0);
    }
    close(conn);
  }
}
