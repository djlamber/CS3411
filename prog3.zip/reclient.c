#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <strings.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <error.h>

char msg[100];
int main(int argc, char **argv) {
  char *remhost; unsigned short remport;
  int sock, left, num, put;
  char buff[100];
  char ch;
  int i = 0;
  struct sockaddr_in remote;
  struct hostent *h;
  
  if(argc < 4){
    sprintf(buff, "Invalid input, please use the following format:\n./reclient <address> <port> <command> <args>");
    puts(buff);
    exit(0);
  }
  if(argc > 4){
    sprintf(msg, "%s,%s", argv[3], argv[4]);
  }else{
    sprintf(msg, "%s", argv[3]);
  }
  remhost = argv[1]; remport = atoi(argv[2]);
  sock = socket(AF_INET, SOCK_STREAM, 0);

  bzero((char *) &remote, sizeof(remote));
  remote.sin_family = (short) AF_INET;
  h = gethostbyname(remhost);
  bcopy((char *)h->h_addr, (char *)&remote.sin_addr,
	h->h_length);
  remote.sin_port = htons(remport);
  connect(sock, (struct sockaddr *)&remote, sizeof(remote));
  left = sizeof(msg); put = 0;
  /*write to socket*/
  while(left > 0) {
    if((num = write(sock, msg+put, left)) < 0) {
      perror("inet_wstream: write");
      exit(1);
    }
    else {
      left -= num;
      put += num;
    }
  }
  char buffer[1];
  i = 0;
  /*reads from socket and prints output*/
  while(read(sock, &ch, 1) == 1){
    buffer[0] = ch;
    write(STDOUT_FILENO, buffer, 1); 
  }
  exit(0);
}
