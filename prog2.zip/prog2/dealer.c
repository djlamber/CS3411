#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <signal.h>
#include <time.h>

/*swaps the values of two integers*/
void swap(int *x, int *y){
  int z;
  z = *x;
  *x = *y;
  *y = z;
}

/*generates a shuffled deck of cards*/
void generateDeck(int *playdeck){
  int deck[52];
  int i = 0;
  while(i<52){
    deck[i] = (i/4)+1;
    i++;
  }
  i = 0;
  /*shuffles deck a random amount*/
  srand(time(NULL));
  int iter = 52 + rand() / (RAND_MAX / (150 - 53) +1);
  while(i < iter){
    int rand1 = 0 + rand() / (RAND_MAX / (51 - 1) +1);
    int rand2 = 0 + rand() / (RAND_MAX / (51 - 1) +1);
    swap(&deck[rand1], &deck[rand2]);
    i++;
  }
  i=0;
  while(i<52){
    playdeck[i] = deck[i];
    i++;
  }
}


int main(int argc,char** argv[]){
  char str[100];
  if(argc > 2 || argc < 2){
    sprintf(str, "Incorrect number of arguments please use the following format:\n./dealer <number of players>");
    puts(str);
    exit(0);
  }
  int numPlayers = atoi(argv[1]);
  if(numPlayers <= 0){
    sprintf(str, "Incorrect input please supply a positive integer in the following format:\n./dealer <number of players>");
    puts(str);
    exit(0);
  }

  /*initalize variables*/
  int i = 0;
  int j = 0;
  int deck[52];
  int remainingCards = 52;
  int playerPID[numPlayers];
  int remainingPlayers = numPlayers;
  int knockedOutPlayers[numPlayers];
  int parentPID;
  int childWait;
  bool playing = true;
  bool skip;
  int lowest;
  int lowestPlayer;
  int reading_buf[1];
  int pipefd[numPlayers*2][2];
  int hand[4];
  char* input[2] = {"player", NULL};;

  generateDeck(deck);
  /*initalizes array*/
  while(i<numPlayers){
    knockedOutPlayers[i] = -1;
    i++;
  }

  /*creates communication pipes*/
  for(i = 0; i < numPlayers*2; i++){
    if(pipe(pipefd[i]) == -1){
      sprintf(str, "Pipe creation failure");
      puts(str);
      exit(0);
    }
  }

  /*Creates player processes*/
  i=0;
  while(i < numPlayers){
    playerPID[i] = fork();
    if(playerPID[i] == 0){
      dup2(pipefd[i*2][0], STDIN_FILENO); /*redirect stdin*/
      dup2(pipefd[(i*2)+1][1], STDOUT_FILENO); /*redirect stdout*/
      close(pipefd[i*2][0]);
      close(pipefd[(i*2)+1][1]);
      execvp("./player",input);
      sprintf(str, "exec failed");
      puts(str);
      exit(1);
    }
    i++;
  }
  /*Play the game*/
  while(playing){

    /*if less than 2 players end the game*/
    if(remainingPlayers < 2){
      playing = false;
      break;
    }
    lowestPlayer = -1;
    i = 0;

    /*deal cards to players*/
    while(i < numPlayers){
      skip = false;
      /*skip players that have been knocked out*/
      for(j = 0; j < numPlayers; j++){
	if(i == knockedOutPlayers[j]){
	  skip = true;
	  break;
	}
      }
      if(skip){
	i++;
	continue;
      }
      hand[0] = deck[remainingCards-1];
      hand[1] = deck[remainingCards-2];
      hand[2] = deck[remainingCards-3];
      hand[3] = deck[remainingCards-4];
      remainingCards = remainingCards - 4;
      sprintf(str, "Dealing [%d, %d, %d, %d] to player %d.", hand[0], hand[1], hand[2], hand[3], i+1);
      puts(str);
      write(pipefd[i*2][1], &hand, sizeof(int) * 4);
      /*if dealer runs out of cards reshuffle deck*/
      if(remainingCards <=0){
	generateDeck(&deck);
	remainingCards = 52;
      }
      i++;
    } 

    /*compare results*/
    i=0;
    lowest = 53;/*players shouldn't be able to report back higher than 52 unless they are cheating*/
    while(i < numPlayers){

      skip = false;
      /*skip players that have been knocked out*/
      for(j=0; j<numPlayers; j++){
	if(i == knockedOutPlayers[j]){
	  skip = true;
	}
      }
      if(skip){
	i++;
	continue;
      }

      /*read and print results*/
      read(pipefd[(i*2)+1][0], &reading_buf, sizeof(int));
      sprintf(str, "Player %d reports a total of %d.", i+1, reading_buf[0]);
      puts(str);

      /*if a tie for lowest happens*/
      if(reading_buf[0] == lowest){
	bool tie = true;
	int currBuff = reading_buf[0];
	int tieTemp;
	while(tie){
	  sprintf(str, "Tie between player %d and player %d.", i+1, lowestPlayer+1);
	  puts(str);
	  /* deals to player i for tie*/
	  hand[0] = deck[remainingCards-1];
          hand[1] = deck[remainingCards-2];
          hand[2] = deck[remainingCards-3];
          hand[3] = deck[remainingCards-4];
	  remainingCards = remainingCards - 4;
	  sprintf(str, "Dealing [%d, %d, %d, %d] to player %d.", hand[0], hand[1], hand[2], hand[3], i+1);
	  puts(str);
	  write(pipefd[i*2][1], &hand, sizeof(int) * 4);
	  /*if dealer runs out of cards reshuffle deck*/
	  if(remainingCards <=0){
	    generateDeck(&deck);
	    remainingCards = 52;
	  }
	  /*deals to current low player for tie*/
	  hand[0] = deck[remainingCards-1];
	  hand[1] = deck[remainingCards-2];
	  hand[2] = deck[remainingCards-3];
	  hand[3] = deck[remainingCards-4];
	  remainingCards = remainingCards - 4;
	  sprintf(str, "Dealing [%d, %d, %d, %d] to player %d.", hand[0], hand[1], hand[2], hand[3], lowestPlayer+1);
	  puts(str);
	  write(pipefd[lowestPlayer*2][1], &hand, sizeof(int) * 4);
	  /*if dealer runs out of cards reshuffle deck*/
	  if(remainingCards <=0){
	    generateDeck(&deck);
	    remainingCards = 52;
	  }
	  read(pipefd[(i*2)+1][0], &reading_buf, sizeof(int));
	  tieTemp = reading_buf[0];
	  sprintf(str, "Player %d reports a total of %d.", i+1, tieTemp);
	  puts(str);
	  read(pipefd[(lowestPlayer*2)+1][0], &reading_buf, sizeof(int));
	  sprintf(str, "Player %d reports a total of %d.", lowestPlayer+1, reading_buf[0]);
	  puts(str);
	  
	  if(tieTemp < reading_buf[0]){ /*if i is lower than current low*/
	    reading_buf[0] = currBuff;
	    lowest++;
	    lowestPlayer = i;
	    tie = false;
	    continue;
	  }if(tieTemp == reading_buf[0]){ /*another tie, do tiebreaker again*/
	      continue;
	  }if(tieTemp > reading_buf[0]){ /*if current low is lower than i*/
	    tie = false;
	  }
	}
      }
      /*if lower than current lowest*/
      if(reading_buf[0] < lowest){
	lowest = reading_buf[0];
	lowestPlayer = i;
      }
      i++;
    }

    /*remove bottom player*/
    sprintf(str, "Player %d has been knocked out!", lowestPlayer+1);
    puts(str);
    kill(playerPID[lowestPlayer], SIGUSR1);
    knockedOutPlayers[remainingPlayers-1] = lowestPlayer;    
    remainingPlayers--;
  }

  int temp = 0;
  int winner = 0;
  /*find winners PID*/
  for(i = 0; i < numPlayers; i++){
    temp = 0;
    for(j = 0; j < numPlayers; j++){
      if(knockedOutPlayers[j] == i){
	temp = winner;
	break;
      }else{
	temp = i;
      }
    }
    winner = temp;
  }
  kill(playerPID[winner], SIGUSR1);
  sprintf(str, "Player %d wins!\nEnding the game.", winner +1);
  puts(str);
  exit(0);
  return 0;
}
