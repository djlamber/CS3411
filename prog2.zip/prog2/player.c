#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void main(int argc,char** argv[]){;
  int buff[1];
  int total;
  while(1){
    total = 0;
    read(STDIN_FILENO, &buff, sizeof(int));
    total += buff[0];
    read(STDIN_FILENO, &buff, sizeof(int));
    total += buff[0];
    read(STDIN_FILENO, &buff, sizeof(int));
    total += buff[0];
    read(STDIN_FILENO, &buff, sizeof(int));
    total += buff[0]; 
    write(STDOUT_FILENO, &total, sizeof(int));
  }
}
